import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-customermenu',
  templateUrl: './customermenu.component.html',
  styleUrls: ['./customermenu.component.css']
})
export class CustomermenuComponent implements OnInit {

  constructor(private activatedroute:ActivatedRoute,private router:Router) { }

  phoneNo:any;

  ngOnInit(): void {

    this.phoneNo=this.activatedroute.snapshot.paramMap.get('phoneNo')
    console.log(this.phoneNo)
  }

  logout()
  {
    this.router.navigate(['']);
    window.alert("Logging Out::::::::::Customer")
  }
 

}
