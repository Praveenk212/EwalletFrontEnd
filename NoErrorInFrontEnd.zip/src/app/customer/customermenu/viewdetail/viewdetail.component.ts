import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewdetail',
  templateUrl: './viewdetail.component.html',
  styleUrls: ['./viewdetail.component.css']
})
export class ViewdetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
