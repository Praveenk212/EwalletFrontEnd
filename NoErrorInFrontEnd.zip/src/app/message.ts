export class message
{
    message:any;
    public constructor(message:any)
    {
    this.message=message;
    }

}
