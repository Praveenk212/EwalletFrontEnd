import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-getalltransaction',
  templateUrl: './getalltransaction.component.html',
  styleUrls: ['./getalltransaction.component.css']
})
export class GetalltransactionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
