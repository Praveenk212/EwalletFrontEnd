import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminComponent } from './admin/admin.component';
import { CustomerComponent } from './customer/customer.component';
import { ContactusComponent } from './contactus/contactus.component';
import { NewcustomeraccountComponent } from './customer/newcustomeraccount/newcustomeraccount.component';
import { AdminmenuComponent } from './admin/adminmenu/adminmenu.component';
import { CustomermenuComponent } from './customer/customermenu/customermenu.component';
import { CustomerlistComponent } from './admin/adminmenu/customerlist/customerlist.component';
import { GetaccountstoapproveComponent } from './admin/adminmenu/getaccountstoapprove/getaccountstoapprove.component';

const routes: Routes = [

  { path: 'newcustomeraccount', component: NewcustomeraccountComponent },

  { path: 'admin', component: AdminComponent },
  { path: 'customer', component: CustomerComponent },
  { path: 'contactus', component: ContactusComponent },
  { path: 'admin/adminmenu', component: AdminmenuComponent,
  children: [
    { path: 'customerlist', component: CustomerlistComponent },
    {path:'getaccountstoapprove',component:GetaccountstoapproveComponent},
  ]
},






  {
    path: 'customer/customermenu/:phoneNo', component: CustomermenuComponent,}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
  AdminComponent;
  CustomerComponent;
  ContactusComponent;
  NewcustomeraccountComponent
 }
