export class customer {
	//Data Field Declaration

	phoneNo: number;
	password: any;
	custName: any;
	age: number;
	gender: any;
	emailId: any;
	accountStatus: any;


	// staticRequestId:any;
	// requestId:any;
	//Constructor using all field

	constructor(phoneNo, passWord, custName, age, gender,emailId) {
		this.phoneNo = phoneNo;
		this.password = passWord;
		this.custName = custName;
		this.age = age;
		this.gender = gender;
		this.emailId = emailId;
		this.accountStatus="pending";
	}
}