import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable} from 'rxjs';
import { throwError } from 'rxjs';
import {retry,catchError} from 'rxjs/operators';
import { customerlogindetail } from './CustomerLogin';
import { customer } from './customer';

@Injectable({
  providedIn: 'root'
})
export class CustomerserviceService {

  private options = { headers: new HttpHeaders().set('Content-Type', 'application/json') };
  constructor(private httpClient:HttpClient) { }

  accountServiceUrl:String="http://localhost:8089";


  validateCustomer(cust:customerlogindetail):Observable<boolean>{
    return this.httpClient.post<boolean>('http://localhost:9097/customer-login',cust,this.options);
  }

  newCustomerAccount(customer:customer):Observable<String>
  {
    return this.httpClient.post<String>(this.accountServiceUrl+'/newcustomer',customer,this.options)
  }

  errorhand(error)
  {
    return throwError(error);
  }
}
