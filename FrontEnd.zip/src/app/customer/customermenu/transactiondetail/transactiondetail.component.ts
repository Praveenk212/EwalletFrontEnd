import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transactiondetail',
  templateUrl: './transactiondetail.component.html',
  styleUrls: ['./transactiondetail.component.css']
})
export class TransactiondetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
