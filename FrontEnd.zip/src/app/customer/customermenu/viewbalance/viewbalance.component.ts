import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewbalance',
  templateUrl: './viewbalance.component.html',
  styleUrls: ['./viewbalance.component.css']
})
export class ViewbalanceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
