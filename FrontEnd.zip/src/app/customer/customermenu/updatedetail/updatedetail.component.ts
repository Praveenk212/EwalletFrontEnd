import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-updatedetail',
  templateUrl: './updatedetail.component.html',
  styleUrls: ['./updatedetail.component.css']
})
export class UpdatedetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
